export enum AsteroidSize
{
	Large,
	Medium,
	Small,
	Dust
}
