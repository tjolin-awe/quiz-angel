export enum SceneKeys
{
	TitleScreen = 'titlescreen',
	GameBackground = 'game-background',
	Game = 'game',
	GameUI = 'game-ui',
	GameOver = 'game-over'
}
