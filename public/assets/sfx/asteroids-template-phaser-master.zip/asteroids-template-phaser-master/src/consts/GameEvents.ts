export enum GameEvents
{
	AsteroidBroken = 'asteroid-broken',
	PointsScored = 'points-scored'
}
