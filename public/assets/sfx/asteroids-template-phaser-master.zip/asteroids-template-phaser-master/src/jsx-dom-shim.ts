import * as React from 'jsx-dom'

window['React'] = React

export default React
